export const API_URL = 'http://localhost:8080';
export const JPA_API_URL = 'http://localhost:8080/jpa';
export const WEB_SOCKET_URL = 'http://localhost:8083/ws';
export const GATEWAY_JPA_API_URL = 'http://localhost:8080/follow-service/jpa'
export const GATEWAY_POST_JPA_API_URL = 'http://localhost:8080/post-service/post'
// export const JPA_API_URL = 'http://localhost:8083/jpa'
